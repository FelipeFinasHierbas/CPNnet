<?php
/**
 * Plugin Name:       CPNnet Asistente Comercial
 * Description:       Chat con IA (Claude) para www.cpnnetsecurity.com: orienta a partners y empresas sobre el portafolio de CPNnet y deriva los leads por WhatsApp.
 * Version:           0.7.0
 * Requires PHP:      8.1
 * Requires at least: 6.0
 * Author:            CPNnet Security
 * Text Domain:       cpnnet-asistente
 */

if (!defined('ABSPATH')) {
    exit;
}

if (defined('CPNNET_ASISTENTE_VERSION')) {
    // Ya hay otra variante del asistente activa: no cargar dos a la vez.
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>Asistente comercial:</strong> hay dos variantes del asistente activas a la vez. Desactiva una de ellas.</p></div>';
    });
    return;
}

define('CPNNET_ASISTENTE_VERSION', '0.7.0');
define('CPNNET_ASISTENTE_DIR', plugin_dir_path(__FILE__));
define('CPNNET_ASISTENTE_URL', plugin_dir_url(__FILE__));
define('CPNNET_ASISTENTE_OPTION', 'cpnnet_asistente');

if (is_readable(CPNNET_ASISTENTE_DIR . 'vendor/autoload.php')) {
    require_once CPNNET_ASISTENTE_DIR . 'vendor/autoload.php';
} else {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>Asistente CPNnet:</strong> falta la carpeta <code>vendor/</code> del plugin (SDK de Anthropic). Reinstala el .zip generado con build.sh.</p></div>';
    });
    return;
}

require_once CPNNET_ASISTENTE_DIR . 'includes/brand.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/settings.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/leads.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/usage.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/kb.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/prompt.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/api.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/widget.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/integration.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/admin.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/dashboard.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/booking.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/booking-mail.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/booking-portal.php';
require_once CPNNET_ASISTENTE_DIR . 'includes/booking-admin.php';

register_activation_hook(__FILE__, 'cpnnet_asistente_activate');
register_deactivation_hook(__FILE__, static fn() => wp_clear_scheduled_hook('cpnnet_asistente_booking_tick'));

function cpnnet_asistente_activate(): void
{
    cpnnet_asistente_leads_create_table();
    cpnnet_asistente_usage_create_table();
    cpnnet_asistente_ensure_role();
    if (cpnnet_asistente_booking_enabled()) {
        cpnnet_asistente_booking_create_tables();
        cpnnet_asistente_booking_ensure_role();
        cpnnet_asistente_generate_sessions();
    }
    if (get_option(CPNNET_ASISTENTE_OPTION) === false) {
        add_option(CPNNET_ASISTENTE_OPTION, cpnnet_asistente_defaults());
    }
}
